Boas vindas � nossa rede social, modelada utilizando grafos!

Para a utiliza��o dessa aplica��o, voc� deve:

- Primeiro: compilar o seu programa
(se achar mais f�cil, basta utilizar a diretiva 'all' do makefile atrav�s
do comando 'make' no terminal, desde que possua os programas 'gcc' para compilar o c�digo e 'make' instalado na m�quina);

- Segundo: executar o programa
(se achar mais f�cil, basta utilizar a diretiva 'run' do makefile atrav�s
do comando 'make run' no terminal, desde que possua os programas 'gcc' e 'make' instalado na m�quina).

Para informa��es mais completas, favor, abrir o PDF anexado nessa pasta.

Obrigado e bom uso! ;)