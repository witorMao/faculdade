/**
 * Representa um tipo de ContaPoupança, a Conta PoupançaOuro
 * @author delamaro
 *
 */
public class PoupançaOuro extends ContaPoupanca{
	
	public PoupançaOuro(String n, int d) {
		super(n, d);
	}
	
	public void atualiza(double taxa) {
		double s = getSaldo();
		setSaldo(s * (1.5 + taxa));
	}

}
