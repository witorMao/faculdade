/**
 * Representa um tipo de ContaPoupança, a Conta PoupançaSimples
 * @author delamaro
 *
 */
public class PoupançaSimples extends ContaPoupanca {
	
	public PoupançaSimples(String n, int d) {
		super(n, d);
	}
	
	public void atualiza(double taxa) {
		double s = getSaldo();
		setSaldo(s * (1.0 + taxa));
	}
}
