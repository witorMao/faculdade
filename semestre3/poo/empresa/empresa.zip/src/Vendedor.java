public class Vendedor extends Funcionario {
	private double comissao;
	public Vendedor(String n, String c, double s, double co) {
		super(n, c, s);
		this.comissao = co;
	}
	
	public double calculaSalario() {
		return (this.getSalarioBase() + this.comissao);
	}
	
}