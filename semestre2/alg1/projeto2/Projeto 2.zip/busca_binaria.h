#include <stdio.h>

int busca_binaria(int* v, int chave, int ini, int fim, int *posicao);
int insere_vetor_bb(int *vet, int tam, int *num_elem, int x);
int remove_vetor_bb(int *vet, int tam, int *num_elem, int x);
void print_vetor(int *vet, int num_elem);