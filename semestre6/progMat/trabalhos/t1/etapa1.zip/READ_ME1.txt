Os passos a seguir servem para executar o programa na plataforma em nuvem Google Colab:

[1]Para executar o codigo, abra o site do google colab logado com o email usp(https://colab.research.google.com/)

[2]Descompacte o arquivo enviado clicando com o botão direito, e depois clicando em "extrair aqui"

[3]Abra o arquivo notebook com o nome "trabalho1.ipynb" incluso no zip enviado(a ferramenta utilizada como solver é importada dentro do código)

[4]Após aberto o arquivo, para executar clique na tecla F9

[5]Após isso o código vai ser executado e o resultado aparecerá no final do documento.