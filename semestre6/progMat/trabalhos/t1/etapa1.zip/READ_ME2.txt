Os passos a seguir servem para executar o programa diretamente na máquina do usuário:

[1]Primeramente, é necessário que tenha uma versao da linguagem de programaçao Python instalada no seu computador, recomenda-se da versão 3.8 ou mais recente 

[2]Depois deve instalar a biblioteca PulP (tutorial de como instalar: https://coin-or.github.io/pulp/main/installing_pulp_at_home.html), ela foi a ferramenta utilizada como solver

[3]Descompacte o arquivo enviado clicando com o botão direito e selecionando "extrair aqui"

[4]Execute o código fonte com o nome "trabalho1.py" incluso no zip enviado

[5]Após isso o código vai ser executado e o resultado aparecerá no terminal utilizado