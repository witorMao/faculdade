Filtros aplicados:

- ReplaceMissingValues;
- RemoveDuplicates;
- Normalize;