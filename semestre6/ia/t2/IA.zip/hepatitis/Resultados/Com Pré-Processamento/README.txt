Filtros aplicados:

- ReplaceMissingValues;
- Discretização no atributo Bilirubin, conforme recomendação dos criadores do dataset;