Balance Scale é um dataset perfeito. 

Aplicamos a classificação somente sem processamento.