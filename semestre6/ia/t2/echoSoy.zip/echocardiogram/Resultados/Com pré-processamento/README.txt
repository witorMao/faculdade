Filtros aplicados:

- ReplaceMissingValue;
- RemoveDuplicates (não fez diferença);
- MathExpression (rint(A)) só no atributo Survival, lvdd;